require({cache:{
'url:epi-ecf-ui/contentediting/editors/templates/ManageGroupDefinitionDialog.html':"﻿<div>\r\n    <label for=\"name\">${resources.name} </label>\r\n    <div data-dojo-type=\"dijit/form/ValidationTextBox\" data-dojo-attach-point=\"nameTextBox\" name=\"name\" required=\"true\" data-dojo-props=\"intermediateChanges:true, regExp:'^[A-Za-z0-9]([A-Za-z0-9 _\\-])*$'\"></div>\r\n</div>"}});
﻿define("epi-ecf-ui/contentediting/editors/AddRelationGroupDefinitionCommand", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/when",
    // dijit
    "dijit/_Widget",
    "dijit/_TemplatedMixin",
    "dijit/_WidgetsInTemplateMixin",
    "dijit/form/ValidationTextBox",
    // epi
    "epi/dependency",
    "epi/shell/command/_Command",
    // epi-cms
    "epi-cms/contentediting/command/_CommandWithDialogMixin",
    // resources
    "epi/i18n!epi/nls/episerver.shared",
    "epi/i18n!epi/cms/nls/commerce.command.addgroup",
    "dojo/text!./templates/ManageGroupDefinitionDialog.html"

], function (
    // dojo
    declare,
    lang,
    when,
    // dijit
    _Widget,
    _TemplatedMixin,
    _WidgetsInTemplateMixin,
    ValidationTextBox,
    // epi
    dependency,
    _Command,
    // epi-cms
    _CommandWithDialogMixin,
    // resources
    sharedResources,
    commandResources,
    template
) {
    var AddGroupDefinitionContent = declare([_Widget, _TemplatedMixin, _WidgetsInTemplateMixin], {

        templateString: template,

        store: null,

        resources: sharedResources.header,

        constructor: function () {
            this.store = this.store || dependency.resolve("epi.storeregistry").get("epi.commerce.relationgroupdefinition");
        },

        saveToStore: function () {
            if (this.nameTextBox.validate()) {
                return this.store.put({
                    name: this.nameTextBox.value
                });
            }
        }
    });

    return declare([_Command, _CommandWithDialogMixin], {
        dialogContentClass: AddGroupDefinitionContent,

        dialogClass: "epi-dialog-confirm",

        // Set autofocus to false to prevent the validate the require fields when opening dialog.
        dialogParams: { autofocus: true },

        iconClass: "epi-iconPlus",

        confirmActionText: sharedResources.action.add,

        title: commandResources.title,

        postscript: function () {
            // summary:
            //      Hide close icon
            // tags:
            //      public override
            this.inherited(arguments);

            if (!this.dialogParams) {
                this.dialogParams = {};
            }

            this.dialogParams.closeIconVisible = false;
        },

        _execute: function () {
            // summary:
            //      Executes this command assuming canExecute has been checked.
            // tags:
            //      protected override
            this.showDialog();

            if (this._dialog) {
                this._setDialogConfirmActionStatus();

                this.dialogContent.nameTextBox.on("change", lang.hitch(this, this._setDialogConfirmActionStatus));
            }
        },

        _setDialogConfirmActionStatus: function () {
            this._dialog.onActionPropertyChanged({ name: this._dialog._okButtonName }, "disabled", !this.dialogContent.nameTextBox.validate());
        },

        onDialogExecute: function () {
            when(this.dialogContent.saveToStore(), lang.hitch(this, this.onSaved));
        },

        onSaved: function () {
            // summary:
            //      Process value when saved store.
            //      Need to override.
            // tags:
            //      public virtual 
        },

        canExecute: true
    });
});
