﻿define("epi-ecf-ui/store/Aggressive", [
    "dojo/_base/array",
    "dojo/_base/lang",
    "dojo/store/Memory",
    "dojo/store/Observable",
    "dojo/when",

    "epi/shell/TypeDescriptorManager",

    "epi-cms/core/ContentReference"
    ],
function (
    array,
    lang, 
    MemoryStore,
    Observable,
    when,

    TypeDescriptorManager,

    ContentReference
) {

    var Aggressive = function (masterStore, options) {
        // summary:
        //      The Aggressive store wrapper takes a store and loads all data to memory when a 
        //      first request is made.
        //
        // description:
        //      Aggressive wraps an existing store so that all data under rootId will be loaded 
        //      to memory in the first load.
        //      It was made to provide the best performance when filtering data on DiscountTree, 
        //      as well as to be able to re-used in DiscountList widget.
        // tags:
        //      internal

        if (!options.rootId) {
            throw new Error("The options must specify the Id of the root content to get children from (rootId).");
        }

        options = lang.mixin({
            idProperty: "contentLink",
            queryName: "getdescendents",
            queryEngine: masterStore.queryEngine,
            defaultQueryOptions: {
                ignore: ["query"],
                comparers: {
                    "typeIdentifiers": function (queryValue, instance) {
                        return array.some(queryValue, function (item) {
                            return item === instance.typeIdentifier || TypeDescriptorManager.isBaseTypeIdentifier(instance.typeIdentifier, item);
                        });
                    },
                    "referenceId": function (queryValue, instance) {
                        return ContentReference.compareIgnoreVersion(queryValue, instance.parentLink);
                    }
                }
            }
        }, options);

        var memoryStore = Observable(new MemoryStore(options));

        var store = lang.delegate(masterStore, {
            patchCache: function (object) {
                // an empty patchCache function to make it patchable
            },

            refresh: function (id) {
                var contentLink = ContentReference.toContentReference(id);
                return when(masterStore.get(contentLink.id.toString())).then(lang.hitch(this, function (content) {
                    if (!content || content.statusCode === 404) { // content not found, it was removed
                        return this._removeDescendents(id);
                    } else {
                        return memoryStore.put(content);
                    }
                }));
            },

            _removeDescendents: function (id) {
                memoryStore.remove(id);
                when(this.query({ parentLink: id })).then(lang.hitch(this, function (children) {
                    children.forEach(function (child) {
                        this._removeDescendents(child.contentLink);
                    }, this);
                }));
            },

            put: function (object, directives) {
                return when(_initDataPromise, function () {
                    return when(masterStore.put(object, directives), function (result) {
                        memoryStore.put(object && typeof result === "object" ? result : object, directives);
                        return result;
                    });
                });
            },

            add: function (object, directives) {
                return when(_initDataPromise, function () {
                    return when(masterStore.add(object, directives), function (result) {
                        memoryStore.add(object && typeof result === "object" ? result : object, directives);
                        return result;
                    });
                });
            },

            remove: function (id) {
                return when(_initDataPromise, function () {
                    return when(masterStore.remove(id), function (result) {
                        return memoryStore.remove(id);
                    });
                });
            },

            get: function (id, directives) {
                return when(_initDataPromise, function () {
                    return memoryStore.get(id, directives);
                });
            },

            query: function (query, directives) {
                directives = lang.delegate(options.defaultQueryOptions, directives || {});
                if (_initDataPromise && _initDataPromise.isResolved()) {
                    return memoryStore.query(query, directives);
                }

                var results;
                var promise = when(_initDataPromise).then(function () {
                    results = memoryStore.query(query, directives);
                    return results;
                });

                // call to query assumes that the returned promise to have the observe function.
                // route the delegate to the inner data when it is ready
                if (!promise.observe) {
                    return lang.delegate(promise, {
                        observe: function (listener, includeObjectUpdates) {
                            var actualHandle;
                            when(promise).then(function () {
                                actualHandle = results.observe(listener, includeObjectUpdates);
                            });

                            var handle = {};
                            handle.remove = handle.cancel = function () {
                                when(promise).then(function () {
                                    actualHandle.cancel();
                                });
                            };
                            return handle;
                        }
                    });
                }

                return promise;
            }
        });

        var _queryParams = {
            query: options.queryName,
            referenceId: options.rootId,
            typeIdentifiers: options.typeIdentifiers,
            includeRoot: options.includeRoot
        };
        var _initDataPromise = when(masterStore.query(_queryParams), function (data) {
            memoryStore.setData(data || []);
            return data;
        });

        masterStore.addDependentStore(store, { refreshOnPatch: true, refresh: function (obj) {
            // there is bug in patchables.js (CMS-2959, CMS UI 9.4.1) which ends up in a recursive loop.
            // here is a fix so Commerce would work with/without that CMS bugfix.
            store.refresh(store.getIdentity(obj));
        }});
        return store;
    };

    return Aggressive;
});
