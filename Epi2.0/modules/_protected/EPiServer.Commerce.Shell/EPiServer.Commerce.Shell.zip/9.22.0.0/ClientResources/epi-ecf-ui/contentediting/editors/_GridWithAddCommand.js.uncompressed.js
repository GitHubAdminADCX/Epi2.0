﻿define("epi-ecf-ui/contentediting/editors/_GridWithAddCommand", [
    // dojo
    "dojo/_base/declare",
    "dojo/_base/lang",
    "dojo/aspect",
    "dojo/dom-construct",
    "dojo/dom-style",
    "dojo/dom-geometry",
    // dijit
    "dijit/layout/_LayoutWidget",
    "dijit/_TemplatedMixin",
    // dgrid
    "dgrid/OnDemandGrid",
    "dgrid/Selection",
    // epi
    "epi/dependency",
    "epi/shell/command/_Command",
    "epi/shell/command/builder/ButtonBuilder",
    "epi/shell/widget/dialog/_DialogContentMixin",
    // epi-ecf-ui
    "./AddRelationGroupDefinitionCommand",
    // resources
    "epi/i18n!epi/cms/nls/commerce.contentediting.editors.relationgroupeditor"
], function (
    // dojo
    declare,
    lang,
    aspect,
    domConstruct,
    domStyle,
    domGeometry,
    // dijit
    _LayoutWidget,
    _TemplatedMixin,
    // dgrid
    Grid,
    Selection,
    // epi
    dependency,
    _Command,
    ButtonBuilder,
    _DialogContentMixin,
    // epi-ecf-ui
    AddRelationGroupDefinitionCommand,
    // resources
    resources
) {
    return declare([_LayoutWidget, _TemplatedMixin, _DialogContentMixin], {

        templateString: '<div><div data-dojo-attach-point="addNode"></div></div>',

        store: null,

        grid: null,

        addCommand: null,

        _builder: null,

        storeKey: null,

        // _noDataMessage: string
        //      String to notify that the grid content is empty.
        _noDataMessage: null,

        // _gridClassName: string
        //      List of CSS class name that will be applied for a grid.
        _gridClassName: "epi-plain-grid epi-plain-grid-modal epi-plain-grid--margin-bottom epi-plain-grid--in-dialog",

        constructor: function () {
            this._builder = new ButtonBuilder({ settings: { showLabel: false } });
        },

        postCreate: function () {
            this.inherited(arguments);
            this.store = this.store || dependency.resolve("epi.storeregistry").get(this.storeKey);
            this._setupGrid();
            this.addCommand = this.getAddCommand();
            if (this.addCommand) {
                this._builder.create(this.addCommand, this.addNode);
                // Refresh grid when added item
                this.own(aspect.after(this.addCommand, "onSaved", lang.hitch(this, function () {
                    this.grid.refresh();
                })));
            }
        },

        getAddCommand: function(){
            // summary:
            //      Override to return correct add command.
            // tags:
            //      protected
        },

        _setupGrid: function () {
            var gridType = declare([Grid, Selection]);

            this.grid = new gridType({
                columns: {
                    name: {
                        label: this.getColumnTitle(),
                        sortable: false
                    },
                    action: {
                        className: "epi-columnNarrow",
                        renderHeaderCell: function (node) { },
                        renderCell: lang.hitch(this, function (object, value, node, options) {
                            var deleteCommand = this.getDeleteCommand(object);
                            this._builder.create(deleteCommand, node);
                        }),
                        sortable: false
                    }
                },
                noDataMessage: this._noDataMessage || "",
                store: this.store,
                className: this._gridClassName
            });

            this.grid.set("query", this.getGridQuery());
            this.own(this.grid);
            domConstruct.place(this.grid.domNode, this.domNode);
        },

        getColumnTitle: function(){
            // summary:
            //      Override to return correct title for column in grid.
            // tags:
            //      protected
        },

        getDeleteCommand: function(object){
            // summary:
            //      Override to return correct delete command for rows in grid.
            // tags:
            //      protected

            return new _Command({
                iconClass: "epi-iconClose",
                canExecute: true,
                _execute: lang.hitch(this, function () {
                    var itemId = this.getItemId(object);
                    this.store.remove(itemId).then(lang.hitch(this, function () {
                        this.grid.refresh();
                    }));
                })
            });
        },

        getItemId: function(item){
            // summary:
            //      Override to return correct id for item.
            // tags:
            //      protected
        },

        getGridQuery: function(){
            // summary:
            //      Override to return correct query for this grid.
            // tags:
            //      protected
            return {};
        },

        layout: function () {
            // summary:
            //		Layout the children widgets.
            // tags:
            //		protected

            this.inherited(arguments);

            var dialog = this.getParent();
            if (dialog && dialog.containerNode) {
                // Get the height of container node to calculate the height of content grid node.
                var containerNodeHeight = domGeometry.getContentBox(dialog.containerNode).h,
                    gridHeaderHeight = Math.max(domGeometry.getMarginBox(this.grid.headerNode).h, domStyle.get(this.grid.bodyNode, "margin")),
                    addButtonHeight = domGeometry.getMarginBox(this.addNode).h;

                // Set the size of the grid to be the dialog container height
                domStyle.set(this.domNode, "height", containerNodeHeight + "px");
                domStyle.set(this.grid.contentNode, "height", (containerNodeHeight - addButtonHeight - gridHeaderHeight) + "px");
            }
        }
    });
});